package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * @author tec_feng
 * @create 2019-08-20 14:40
 */
@RestController
public class HelloController {
    @Autowired
    private UserService userService;
    @RequestMapping("hello")
    public List<User> hello(){
        return userService.list();
    }

    @RequestMapping("hello1")
    public List<Var> hello1(){
        return userService.list1();
    }
}
