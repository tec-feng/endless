package com.example.demo;

import org.apache.ibatis.annotations.Mapper;

import java.util.List;

/**
 * @author tec_feng
 * @create 2019-08-20 14:42
 */
@Mapper
public interface UserMapper {
    List<User> list();
    List<Var> list1();
}
