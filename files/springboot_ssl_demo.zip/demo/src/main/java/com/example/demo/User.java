package com.example.demo;

import java.io.Serializable;

/**
 * @author tec_feng
 * @create 2019-08-20 14:39
 */
public class User implements Serializable{
    private String userName;

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }
}
