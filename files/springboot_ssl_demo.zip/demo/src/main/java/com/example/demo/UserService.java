package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @author tec_feng
 * @create 2019-08-20 14:41
 */
@Service
public class UserService {
    @Autowired
    private UserMapper mapper;

    public List<User> list(){return mapper.list();}

    public List<Var> list1(){return mapper.list1();}
}
